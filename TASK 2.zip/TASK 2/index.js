    function MENU_BAR()
    {
        document.getElementById("nav2").style.width="230px";
        document.getElementById("close-btn").style.transition="2s";
        document.getElementById("sidebar").style.display="none";
        document.getElementById("close-btn").style.display="block";



    }
    function CLOSE_BAR(){
        document.getElementById("nav2").style.width="0";
        document.getElementById("close-btn").style.display="none";
        document.getElementById("sidebar").style.display="block";


    }
     let count=0;
    function Change_bg(){
        count++;
        if(count%2!=0){
        document.body.style.backgroundImage="url('/images/Cool wallpaper.jpg)";
        document.body.style.backgroundSize="conatian";
        }
        else{
        document.body.style.backgroundImage="url('./images/Wallpaper\ 4k\ Baby\ Groot\ 4k\ 2019\ Wallpaper.jpeg')";
  
        }

    }
    
